
from keep_alive import keep_alive
from binance.spot import Spot as Client
import time
import pandas as pd
from datetime import datetime
import openpyxl
import os

api_key = os.getenv("api_key")
api_secret = os.getenv("api_secret")

client = Client(api_key, api_secret)
symbol = "BTCUSDT"
quantity_pct = 0.03
bitacora_path = "Bitacora_Trading_Kai.xlsx"

def registrar_en_bitacora(direccion, precio_entrada, cantidad, resultado="", comentario=""):
    try:
        libro = openpyxl.load_workbook(bitacora_path)
        hoja = libro.active
        ahora = datetime.now()
        fila = [ahora.strftime("%Y-%m-%d"), ahora.strftime("%H:%M:%S"), direccion, precio_entrada, cantidad, resultado, comentario]
        hoja.append(fila)
        libro.save(bitacora_path)
        print(f"✅ Bitácora: {direccion} - {cantidad} BTC a {precio_entrada} USD")
    except Exception as e:
        print(f"Error en bitácora: {e}")

def get_klines(interval='1h', lookback=100):
    klines = client.klines(symbol, interval, limit=lookback)
    df = pd.DataFrame(klines, columns=['timestamp','open','high','low','close','volume','close_time','quote_asset_volume','trades','taker_buy_base','taker_buy_quote','ignore'])
    df['close'] = df['close'].astype(float)
    df['volume'] = df['volume'].astype(float)
    return df

def calculate_indicators(df):
    df['ema20'] = df['close'].ewm(span=20).mean()
    df['ema50'] = df['close'].ewm(span=50).mean()
    delta = df['close'].diff()
    gain = delta.where(delta > 0, 0).rolling(14).mean()
    loss = -delta.where(delta < 0, 0).rolling(14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    df['volume_ma'] = df['volume'].rolling(20).mean()
    return df

def get_balance_usdt():
    balances = client.account()['balances']
    usdt_balance = next((item for item in balances if item["asset"] == "USDT"), None)
    return float(usdt_balance['free']) if usdt_balance else 0

def place_order(direction, price):
    usdt = get_balance_usdt()
    qty = round((usdt * quantity_pct) / price, 5)
    side = "BUY" if direction == "long" else "SELL"
    order = client.new_order(symbol=symbol, side=side, type="MARKET", quantity=qty)
    print(f"📈 Orden {direction.upper()} ejecutada - {qty} BTC")
    registrar_en_bitacora(direction.upper(), price, qty)
    return order

def check_signals(df):
    last = df.iloc[-1]
    prev = df.iloc[-2]
    price = last['close']
    if prev['ema20'] < prev['ema50'] and last['ema20'] > last['ema50'] and last['volume'] > last['volume_ma'] and 50 < last['rsi'] < 70:
        place_order("long", price)
    elif prev['ema20'] > prev['ema50'] and last['ema20'] < last['ema50'] and last['volume'] > last['volume_ma'] and 30 < last['rsi'] < 50:
        place_order("short", price)

keep_alive()

while True:
    try:
        df = get_klines()
        df = calculate_indicators(df)
        check_signals(df)
        print("🕒 Ciclo completo. Esperando próxima vela...")
        time.sleep(3600)
    except Exception as e:
        print(f"⚠️ Error: {e}")
        time.sleep(60)
